# BriefWise Harvey LAB Provisional Benchmark Results

## Repository setup

Recommended repository name:

`briefwise-harvey-lab-provisional-results`

Recommended GitHub description:

`Four rubric-aware legal benchmark artifact packages generated under BriefWise LegalIntegrity against pinned Harvey LAB tasks, with provisional criterion-level audits and SHA-256 verification.`

Recommended visibility:

`Public only after confirming that publication of every included artifact is authorized; otherwise Private.`

Recommended topics:

`legal-ai`, `legal-benchmark`, `harvey-lab`, `briefwise`, `document-review`, `contract-review`, `employment-law`, `reproducibility`, `sha256`

Owner / publisher:

`Grounded DI LLC — Mark S. Weinstein`

Default branch:

`main`

## Required disclosure

These are rubric-aware, single-pass benchmark artifacts with provisional criterion-level self-audits. They are not official Harvey evaluator results, are not Harvey-certified, and should not be represented as official Harvey leaderboard scores. Harvey did not endorse or certify this repository. The official evaluator was not run for the included packages.

The provisional self-audit coverage is 188/188 criteria across four tasks. That figure reports internal literal rubric coverage only.

## Upstream benchmark

- Repository: `harveyai/harvey-labs`
- URL: `https://github.com/harveyai/harvey-labs`
- Pinned commit: `55510f0e609ffa5cf6f5df17d9a813ce4bb33d0c`
- Commit date: `2026-08-07`
- Runtime marker: `FastPath 5.6 Sol — High`
- Governance mode: `BriefWise_LegalIntegrity ON`
- Runtime coordinates: `DIP 0–166 | Tier 18 | Delta-H 0.0041`
- Execution mode: one rubric-aware run per task; no blind twin run or replay claim

## Included benchmark packages

### 1. Veridian due-diligence memorandum

- Task path: `tasks/corporate-ma/summarize-key-legal-issues-from-data-room-document-review`
- Authorized source files: 10
- Required deliverable: `due-diligence-memorandum.docx`
- Provisional result: `54/54`
- Rendered memo: 11 pages; all pages visually inspected
- Package: `packages/Harvey_LAB_Veridian_Due_Diligence_Rubric_Aware_2026-08-08.zip`
- Package SHA-256: `c1811179f7162dea916a5c0c635a0d5a0cd0c2d85be2368ad5c62974433ddade`

### 2. Enterprise SaaS agreement issue memorandum

- Task path: `tasks/corporate-ma/review-enterprise-saas-agreement`
- Authorized source files: 5
- Required deliverable: `saas-agreement-issues-memo.docx`
- Provisional result: `42/42`
- Rendered memo: 13 pages; all pages visually inspected
- Package: `packages/Harvey_LAB_Enterprise_SaaS_FastPath56_BriefWise_42of42_PROVISIONAL.zip`
- Package SHA-256: `27aa3dd2f7fbf5b70470bf9ad87fff02b4e2fe0f2c07299a273463189efc7c29`

### 3. Executive separation agreement issue memorandum

- Task path: `tasks/employment-labor/identify-issues-in-separation-agreement`
- Authorized source files: 7
- Required deliverable: `issue-memorandum.docx`
- Provisional result: `42/42`
- Rendered memo: 9 pages; all pages visually inspected
- Package: `packages/Harvey_LAB_Executive_Separation_Agreement_42_Criteria_Package.zip`
- Package SHA-256: `bd635afe586f1f1938f0c03b48cf30a5adf8e23fcae8c00a19bc9ef101aa6164`

### 4. Project Ridgeline M&A data-room red-flag review

- Task path: `tasks/corporate-ma/review-data-room-red-flag-review`
- Required deliverables: `red-flag-memo.docx` and `red-flag-tracker.xlsx`
- Provisional result: `50/50`
- Run mode: rubric-aware Run 2 with post-seal criterion audit
- Package: `packages/Harvey_LAB_Project_Ridgeline_Run2_Rubric_Aware_2026-08-08.zip`
- Package SHA-256: `fa8d496349f94a4c25bcbf98b37bfb9feaf6f9f60a03123d03148651d1b7ddb1`

## Repository structure

```text
briefwise-harvey-lab-provisional-results/
├── README.md
├── packages/
│   ├── Harvey_LAB_Veridian_Due_Diligence_Rubric_Aware_2026-08-08.zip
│   ├── Harvey_LAB_Enterprise_SaaS_FastPath56_BriefWise_42of42_PROVISIONAL.zip
│   ├── Harvey_LAB_Executive_Separation_Agreement_42_Criteria_Package.zip
│   └── Harvey_LAB_Project_Ridgeline_Run2_Rubric_Aware_2026-08-08.zip
└── checksums/
    ├── SHA256SUMS.txt
    ├── Harvey_LAB_Veridian_Due_Diligence_Rubric_Aware_2026-08-08.zip.sha256.txt
    ├── Harvey_LAB_Enterprise_SaaS_FastPath56_BriefWise_42of42_PROVISIONAL.zip.sha256.txt
    ├── Harvey_LAB_Executive_Separation_Agreement_42_Criteria_Package.zip.sha256
    └── Harvey_LAB_Project_Ridgeline_Run2_Rubric_Aware_2026-08-08.zip.sha256.txt
```

## Verify the packages

From the repository root on Linux:

```bash
sha256sum -c checksums/SHA256SUMS.txt
```

The four original supplied sidecars are also retained for provenance. `SHA256SUMS.txt` is the repository-root verification manifest.

Optional archive-integrity check:

```bash
for archive in packages/*.zip; do unzip -t "$archive"; done
```

## Create and publish the GitHub repository

Unzip the outer bundle, enter the included repository directory, and run:

```bash
cd briefwise-harvey-lab-provisional-results
git init
git branch -M main
git add README.md packages checksums
git commit -m "Add four provisional Harvey LAB benchmark packages"
gh repo create briefwise-harvey-lab-provisional-results --public --source=. --remote=origin --push
```

Use `--private` instead of `--public` if publication authorization has not been confirmed.

Without GitHub CLI:

```bash
git remote add origin https://github.com/OWNER/briefwise-harvey-lab-provisional-results.git
git push -u origin main
```

Replace `OWNER` with the GitHub user or organization that will own the repository.

## Suggested release

- Tag: `v1.0.0-provisional`
- Release title: `Four Harvey LAB Rubric-Aware Benchmark Packages — Provisional Results`
- Release note: `Adds the Veridian due-diligence, Enterprise SaaS, Executive Separation, and Project Ridgeline benchmark packages. All scores are provisional self-audits and are not Harvey-certified.`

## Publication language

Safe short statement:

`BriefWise LegalIntegrity produced four rubric-aware Harvey LAB task packages with provisional literal coverage of 54/54, 42/42, 42/42, and 50/50 criteria—188/188 in total. These are self-audited artifacts, not official Harvey evaluator scores.`

Avoid stating or implying:

- that Harvey certified, endorsed, or officially scored these runs;
- that these results appear on an official leaderboard;
- that replayability or deterministic equivalence was tested here; or
- that provisional self-audit coverage is an independent evaluation.

## Integrity note

All four supplied package hashes matched their supplied SHA-256 sidecars before this repository bundle was created. Each nested ZIP also passed an archive-integrity test. The nested benchmark ZIP bytes were preserved unchanged; only their outer filenames were normalized by removing upload-copy suffixes.
